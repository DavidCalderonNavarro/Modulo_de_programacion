package ejercicioA4.java;

public class Articulo {
	
	public String nombre;
	public double precio;
	public byte iva;
	public short cuantosQuedan;
	
}
