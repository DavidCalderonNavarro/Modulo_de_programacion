package ejercicioA1.java;

public class Punto {

	int x;
	int y;
	
}
