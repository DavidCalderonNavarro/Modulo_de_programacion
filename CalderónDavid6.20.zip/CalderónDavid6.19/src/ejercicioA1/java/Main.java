package ejercicioA1.java;

public class Main {

	public static void main(String[] args) {
		
		Punto p1 = new Punto();
		Punto p2 = new Punto();
		Punto p3 = new Punto();
		
		p1.x = 5;
		p1.y = 10;
		
		System.out.println("(" + p1.x + "," + p1.y + ")");
		
	}

}
