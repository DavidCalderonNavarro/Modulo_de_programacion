package ejercicioA3;

public class Rectangulo {
	
	public byte x1;
	public byte x2;
	public byte y1;
	public byte y2;
	
}
