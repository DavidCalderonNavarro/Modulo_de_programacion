package ejercicioA2;

public class Persona {
	
	public  String dni;
	public  String nombre;
	public String apellidos;
	public byte edad;
	
}
