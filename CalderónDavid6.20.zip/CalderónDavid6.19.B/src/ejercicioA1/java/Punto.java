/*Descripción: Declaro dos atributos y un constructor Punto
 * Autor:David Calderón Navarro
 * Fecha:16/01/2026
 */

package ejercicioA1.java;

public class Punto {
	
	//Atributo

	int x;
	int y;
	
	//Constructor
	
	public Punto(int x, int y) {
		
		this.x = x;
		this.y = y;
		
	}
	
}
