/*Descripción: Programa que 
 * Autor:David Calderón Navarro
 * Fecha:15/12/2025
 */

package ejercicio3.java;

public class Ejercicio3 {

	public static void main(String[] args) {
		
		

	}

}
